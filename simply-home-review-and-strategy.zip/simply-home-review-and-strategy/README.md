# Simply Home Review and strategy 

A Pen created on CodePen.

Original URL: [https://codepen.io/Markus-Carter/pen/xbwRYWR](https://codepen.io/Markus-Carter/pen/xbwRYWR).

